<?php

namespace App\Enums\Payment;

use App\Enums\EnumBase;

enum Type : string
{
    use EnumBase;

    case CASH = 'cash';
    case ONLINE = 'online';
}
