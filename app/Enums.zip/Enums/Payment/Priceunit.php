<?php

namespace App\Enums\Payment;

use App\Enums\EnumBase;

enum Priceunit: string
{
    use EnumBase;

    case DOLLAR = 'dollar';
    case RIAL = 'rial';
}
