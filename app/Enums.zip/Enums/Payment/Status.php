<?php

namespace App\Enums\Payment;

use App\Enums\EnumBase;

enum Status : string
{
    use EnumBase;

    case FAILED = 'failed';
    case PENDING = 'pending';
    case FULFILLED = 'fulfilled';
}
